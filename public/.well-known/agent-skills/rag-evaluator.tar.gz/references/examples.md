# Worked Examples

Complete, runnable examples for each common RAG eval setup. Pick the example that matches what the user has, then adapt to their specifics.

All examples:
- Use `from giskard.checks import ...` for checks and `from giskard.agents import Generator` for the judge model
- Select the value under test with `target_key=`
- Wrap scenarios in a `Suite`
- Pass the agent as `target` at run time
- Configure the LLM judge globally with `set_default_generator(...)`
- Guard `result.pass_rate` before formatting: it is `float | None`
- Assume `pip install "giskard[openai,scan]"` and `OPENAI_API_KEY` are in place

---

## Example 1: Black-Box Agent (no KB, no retriever, no Q&A)

**Setup**: User has a callable agent and an agent description, but no documents to ground against.

**Coverage**: Answer relevance, behavioral conformity, refusal quality, paraphrase consistency. No groundedness; be transparent about this.

```python
import asyncio
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, AnswerRelevance, Conformity, SemanticSimilarity,
    FnCheck, set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

# REPLACE: Wire up your actual agent
def your_rag_agent(inputs: str) -> str:
    """Your Q&A agent. Replace this stub."""
    raise NotImplementedError("Replace with your agent")

DOMAIN = "An internal HR assistant that answers employee questions about company benefits, leave policies, and onboarding."

# In-domain question
in_scope = (
    Scenario("vacation_policy")
    .interact(inputs="How many vacation days do I get as a new hire?")
    .check(AnswerRelevance(name="addresses_vacation", context=DOMAIN))
    .check(FnCheck(name="non_empty", fn=lambda trace: len(str(trace.last.outputs).strip()) > 20))
    .with_tags(["Dimension:Relevance"])
)

# Out-of-domain question
out_of_scope = (
    Scenario("unrelated_topic")
    .interact(inputs="What's the weather in Paris today?")
    .check(Conformity(
        name="declines_unrelated",
        rule="The assistant only answers HR questions. For unrelated topics it must decline politely and not invent an answer.",
    ))
    .with_tags(["Dimension:OutOfScope"])
)

# Behavioral check: must not give legal advice
no_legal = (
    Scenario("no_legal_advice")
    .interact(inputs="Can my manager fire me without cause? Is that legal?")
    .check(Conformity(
        name="no_legal_advice",
        rule="The assistant must not provide legal interpretations or advice. It should redirect to HR or legal counsel.",
    ))
    .with_tags(["Dimension:Conformity"])
)

# Paraphrase consistency (same factual question, three phrasings)
paraphrase = (
    Scenario("paraphrase_consistency")
    .interact(inputs="How do I request parental leave?")
    .interact(inputs="Where can I apply for paternity leave?")
    .interact(inputs="leave for new parents, process?")
    .check(SemanticSimilarity(
        name="answers_consistent",
        reference_text_key="trace.interactions[0].outputs",  # compare turn 1 to turn 0
        target_key="trace.interactions[1].outputs",
        threshold=0.7,
    ))
    .with_tags(["Dimension:Paraphrase"])
)

suite = Suite(name="rag_eval_blackbox")
for s in [in_scope, out_of_scope, no_legal, paraphrase]:
    suite.append(s)

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True)
    result.print_report(group_by="Dimension")
    if result.pass_rate is not None:
        print(f"Pass rate: {result.pass_rate:.1%}")
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

Notes:
- `SemanticSimilarity` selects the answer under test with `target_key`, and the reference with `reference_text` / `reference_text_key`. Both must resolve to a single value.
- The three paraphrases live in one multi-turn scenario, so a failure in an early turn skips the rest. That is what you want here: comparing turn 1 to a turn that never ran would be meaningless.

**What's missing here**: groundedness. Tell the user this is the single biggest eval gap and ask if they can share even a few sample chunks.

---

## Example 2: Agent + KB (synthetic Q&A + groundedness)

**Setup**: User has the agent and a KB. Groundedness is anchored to the KB chunks the synthetic question was generated from.

```python
import asyncio
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, Groundedness, AnswerRelevance, Conformity,
    set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

def your_rag_agent(inputs: str) -> str:
    """Your RAG agent. Replace this stub."""
    raise NotImplementedError("Replace with your agent")

DOMAIN = "An assistant that answers questions about our SaaS product's features and pricing."

# REPLACE: Synthetic test set generated from KB chunks. See references/synthetic-qa-generation.md.
TEST_CASES = [
    {
        "question": "How many users are included in the Pro plan?",
        "type": "factual",
        "context": [
            "The Pro plan includes 10 user seats. Additional seats can be purchased at $15/user/month.",
            "All plans include unlimited projects and 24/7 support.",
        ],
        "in_scope": True,
    },
    {
        "question": "What is the price difference between Pro and Enterprise per user, and which is cheaper for a 50-person team?",
        "type": "multi_hop",
        "context": [
            "The Pro plan is $50/month for the first 10 seats, $15/user/month thereafter.",
            "The Enterprise plan is $1500/month flat for up to 100 users.",
        ],
        "in_scope": True,
    },
    {
        "question": "Does the product integrate with SAP S/4HANA?",  # NOT covered by KB
        "type": "out_of_scope",
        "context": [],
        "in_scope": False,
    },
]

scenarios = []
for i, tc in enumerate(TEST_CASES):
    base = Scenario(f"{tc['type']}_{i}").interact(inputs=tc["question"])
    if tc["in_scope"]:
        scenario = (
            base
            .check(Groundedness(
                name="grounded_in_kb",
                context=tc["context"],
            ))
            .check(AnswerRelevance(name="addresses_question", context=DOMAIN))
            .with_tags(["Dimension:Groundedness", f"QuestionType:{tc['type']}"])
        )
    else:
        scenario = (
            base
            .check(Conformity(
                name="declines_when_unsupported",
                rule="When the answer is not in the agent's knowledge base, the agent must explicitly decline or say it does not know. Confident-but-unsupported answers fail this check.",
            ))
            .with_tags(["Dimension:OutOfScope", f"QuestionType:{tc['type']}"])
        )
    scenarios.append(scenario)

suite = Suite(name="rag_eval_with_kb")
for s in scenarios:
    suite.append(s)

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True)
    result.print_report(group_by="QuestionType")
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

Variant — attach the context to the interaction instead of the check. This matches `Groundedness`'s default `context_key="trace.last.metadata.context"`, and keeps the context with the question when the same chunks are reused by several checks:

```python
scenario = (
    Scenario("factual_0")
    .interact(inputs=tc["question"], metadata={"context": tc["context"]})
    .check(Groundedness(name="grounded_in_kb"))       # resolves context from metadata
    .check(Contradiction(name="no_contradiction"))    # same default context_key
)
```

---

## Example 3: Agent + Exposed Retriever (retrieval quality eval)

**Setup**: User exposes both the end-to-end agent AND the retriever as separate functions. Adds retrieval quality eval using multiple metrics from [`retrieval-metrics.md`](./retrieval-metrics.md).

This example imports the metric formulas from the reference. Paste those formulas (`recall_at_k`, `precision_at_k`, `hit_at_k`, `mrr`, `ndcg_at_k`) inline if you want a single self-contained file.

```python
import asyncio
import math
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, Groundedness, AnswerRelevance,
    FnCheck, set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

def your_rag_agent(inputs: str) -> dict:
    """Your RAG agent. Returns {"answer": str, "retrieved_ids": list[str]} so we can eval retrieval."""
    raise NotImplementedError("Replace with your agent")

# ---- Metric formulas (copied inline so this example runs standalone; canonical implementations live in retrieval-metrics.md) ----

def recall_at_k(relevant_ids: set[str], retrieved_ids: list[str], k: int) -> float:
    if not relevant_ids:
        return 1.0
    return len(set(retrieved_ids[:k]) & relevant_ids) / len(relevant_ids)

def precision_at_k(relevant_ids: set[str], retrieved_ids: list[str], k: int) -> float:
    if k == 0:
        return 0.0
    return len(set(retrieved_ids[:k]) & relevant_ids) / k

def mrr(relevant_ids: set[str], retrieved_ids: list[str]) -> float:
    for i, doc_id in enumerate(retrieved_ids, start=1):
        if doc_id in relevant_ids:
            return 1.0 / i
    return 0.0

def ndcg_at_k(relevant_ids: set[str], retrieved_ids: list[str], k: int) -> float:
    if not relevant_ids:
        return 1.0
    top_k = retrieved_ids[:k]
    dcg = sum((1.0 if d in relevant_ids else 0.0) / math.log2(i + 2) for i, d in enumerate(top_k))
    ideal_hits = min(len(relevant_ids), k)
    idcg = sum(1.0 / math.log2(i + 2) for i in range(ideal_hits))
    return dcg / idcg if idcg > 0 else 0.0

# ---- Test set with relevance labels ----

# REPLACE: load your labelled set; each entry needs a question and the doc IDs that should be retrieved
TEST_CASES = [
    {
        "question": "What is the refund policy?",
        "context": ["Full refunds within 30 days; partial after that..."],
        "relevant_ids": {"policy/refunds-v3"},
    },
    # ...
]

K = 5
RECALL_THRESHOLD = 0.8
PRECISION_THRESHOLD = 0.4
MRR_THRESHOLD = 0.5
NDCG_THRESHOLD = 0.7

# ---- FnCheck factories ----

def _retrieved(trace) -> list[str]:
    outputs = trace.last.outputs
    return outputs.get("retrieved_ids", []) if isinstance(outputs, dict) else []

def make_recall_check(relevant_ids: set[str]) -> FnCheck:
    return FnCheck(
        name=f"recall@{K}>={RECALL_THRESHOLD}",
        fn=lambda trace: recall_at_k(relevant_ids, _retrieved(trace), K) >= RECALL_THRESHOLD,
    )

def make_precision_check(relevant_ids: set[str]) -> FnCheck:
    return FnCheck(
        name=f"precision@{K}>={PRECISION_THRESHOLD}",
        fn=lambda trace: precision_at_k(relevant_ids, _retrieved(trace), K) >= PRECISION_THRESHOLD,
    )

def make_mrr_check(relevant_ids: set[str]) -> FnCheck:
    return FnCheck(
        name=f"mrr>={MRR_THRESHOLD}",
        fn=lambda trace: mrr(relevant_ids, _retrieved(trace)) >= MRR_THRESHOLD,
    )

def make_ndcg_check(relevant_ids: set[str]) -> FnCheck:
    return FnCheck(
        name=f"ndcg@{K}>={NDCG_THRESHOLD}",
        fn=lambda trace: ndcg_at_k(relevant_ids, _retrieved(trace), K) >= NDCG_THRESHOLD,
    )

# ---- Build scenarios ----

scenarios = []
for i, tc in enumerate(TEST_CASES):
    scenario = (
        Scenario(f"rag_with_retrieval_{i}")
        .interact(inputs=tc["question"])
        # Retrieval quality: four metrics with thresholds
        .check(make_recall_check(tc["relevant_ids"]))
        .check(make_precision_check(tc["relevant_ids"]))
        .check(make_mrr_check(tc["relevant_ids"]))
        .check(make_ndcg_check(tc["relevant_ids"]))
        # Generation quality: groundedness against the labelled context
        .check(Groundedness(
            name="grounded",
            context=tc["context"],
            target_key="trace.last.outputs.answer",
        ))
        .check(AnswerRelevance(
            name="relevant",
            target_key="trace.last.outputs.answer",
        ))
        .with_tags(["Dimension:Retrieval"])
    )
    scenarios.append(scenario)

suite = Suite(name="rag_eval_full")
for s in scenarios:
    suite.append(s)

# ---- Run, then aggregate raw metric means for trend tracking ----

def aggregate_retrieval_metrics(suite_result, test_cases, k: int = K):
    recalls, precisions, mrrs, ndcgs = [], [], [], []
    for tc, scen in zip(test_cases, suite_result.results):
        outputs = scen.final_trace.last.outputs if scen.final_trace.last else None
        if not isinstance(outputs, dict):
            continue
        retrieved = outputs.get("retrieved_ids", [])
        relevant = set(tc["relevant_ids"])
        recalls.append(recall_at_k(relevant, retrieved, k))
        precisions.append(precision_at_k(relevant, retrieved, k))
        mrrs.append(mrr(relevant, retrieved))
        ndcgs.append(ndcg_at_k(relevant, retrieved, k))
    n = len(recalls) or 1
    return {
        f"recall@{k}_mean": sum(recalls) / n,
        f"precision@{k}_mean": sum(precisions) / n,
        "mrr_mean": sum(mrrs) / n,
        f"ndcg@{k}_mean": sum(ndcgs) / n,
    }

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True)
    result.print_report()
    print("\nRaw metric means:")
    for name, value in aggregate_retrieval_metrics(result, TEST_CASES).items():
        print(f"  {name}: {value:.3f}")
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

Notes:
- `Groundedness` and `AnswerRelevance` use `target_key="trace.last.outputs.answer"` because the agent returns a dict. Without this, they would try to evaluate the whole dict as the answer.
- The cheap deterministic `FnCheck`s are ordered before the LLM judges. Because all checks in a step run against the same trace, a retrieval failure does not suppress the groundedness verdict — you still see both.
- `aggregate_retrieval_metrics` reads `scen.final_trace`, not `scen.trace`; `ScenarioResult` has no `trace` attribute.
- The `FnCheck` thresholds gate the suite (pass/fail). The `aggregate_retrieval_metrics` post-step gives you the raw means alongside, useful for tracking trends across releases without changing thresholds.
- For sparse-label setups (you suspect unlabelled-but-relevant docs in the corpus), swap `recall_at_k` for `inf_ap` (also in [`retrieval-metrics.md`](./retrieval-metrics.md)).

---

## Example 4: Agent + Curated Q&A (gold-answer comparison)

**Setup**: User has a curated test set with reference answers. Use `SemanticSimilarity` and `LLMJudge` for direct comparison; no synthesis needed.

```python
import asyncio
import json
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, SemanticSimilarity, LLMJudge, AnswerRelevance,
    set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

def your_rag_agent(inputs: str) -> str:
    raise NotImplementedError("Replace with your agent")

# REPLACE: Load your golden Q&A
TEST_CASES = json.loads(Path("golden_qa.json").read_text())
# Expected shape: [{"question": str, "reference_answer": str}, ...]

scenarios = []
for i, tc in enumerate(TEST_CASES):
    scenario = (
        Scenario(f"qa_{i}")
        .interact(inputs=tc["question"])
        .check(SemanticSimilarity(
            name="similar_to_gold",
            reference_text=tc["reference_answer"],
            target_key="trace.last.outputs",
            threshold=0.55,
        ))
        .check(LLMJudge(
            name="factually_matches_gold",
            prompt=f"""Compare the agent's answer to the gold answer. Pass if they convey the same factual information, even if worded differently. Fail if the agent's answer omits key facts, adds incorrect facts, or contradicts the gold.

Question: {{{{ trace.last.inputs }}}}
Agent answer: {{{{ trace.last.outputs }}}}
Gold answer: {tc["reference_answer"]}

Return passed=true if the agent's answer is factually equivalent to the gold; passed=false otherwise. Include a one-sentence reason.""",
        ))
        .check(AnswerRelevance(name="relevant"))
        .with_tags(["Dimension:GoldAnswer"])
    )
    scenarios.append(scenario)

suite = Suite(name="rag_eval_against_gold")
for s in scenarios:
    suite.append(s)

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True, max_concurrency=8)
    result.print_report()
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

Notes:
- `SemanticSimilarity` uses `target_key` for the answer under test and `reference_text` for the gold. Default `threshold` is 0.95, which is far too strict for prose — 0.5-0.7 is the useful range.
- The f-string interpolates the gold answer while `{{{{ }}}}` escapes the Jinja2 placeholders that giskard renders. An alternative that avoids the double-escaping entirely is attaching the gold answer as interaction metadata and letting the template read `{{ trace.last.metadata.reference_answer }}`.
- Golden sets tend to be large, so cap concurrency to stay inside provider rate limits.

---

## Example 5: Multi-Turn RAG (follow-up questions)

**Setup**: User wants to test conversational RAG where follow-ups depend on prior turns.

```python
import asyncio
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, Groundedness, AnswerRelevance,
    set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

async def your_rag_agent(inputs: str, trace) -> str:
    """Multi-turn RAG agent. Receives the full trace to maintain conversation state."""
    raise NotImplementedError("Replace with your agent")

POLICY_CHUNKS = [
    "All employees accrue 20 days of paid vacation per year, prorated by start date.",
    "New hires can take up to 5 days in the first 3 months; remaining days unlock at 90 days tenure.",
    "Vacation must be requested at least 2 weeks in advance via the HR portal.",
]

multi_turn = (
    Scenario("vacation_followups")
    .interact(inputs="How many vacation days do I get?")
    .check(Groundedness(name="grounded_1", context=POLICY_CHUNKS))
    .check(AnswerRelevance(name="relevant_1"))
    .interact(inputs="And what if I'm a new hire?")
    .check(Groundedness(name="grounded_2", context=POLICY_CHUNKS))
    .check(AnswerRelevance(name="relevant_2"))
    .interact(inputs="How do I request them?")
    .check(Groundedness(name="grounded_3", context=POLICY_CHUNKS))
    .check(AnswerRelevance(name="relevant_3"))
    .with_tags(["Dimension:MultiTurn"])
)

# Test that the agent maintains context across turns; "it" should resolve to parental leave
context_carry = (
    Scenario("context_carry")
    .interact(inputs="What's the parental leave policy?")
    .interact(inputs="Is it paid?")  # "it" must resolve to parental leave
    .check(AnswerRelevance(
        name="resolves_pronoun",
        context="The user is asking a follow-up about parental leave.",
    ))
    .with_tags(["Dimension:MultiTurn"])
)

suite = Suite(name="rag_multi_turn")
suite.append(multi_turn)
suite.append(context_carry)

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True)
    result.print_report()
    for scenario_result in result.results:
        print(f"[{scenario_result.status.value.upper()}] {scenario_result.scenario_name}")
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

Notes:
- Each `.interact()` starts a new step. A failing step stops the scenario, so if `grounded_1` fails, turns 2 and 3 report **SKIP**, not FAIL. Skipped steps mean "no verdict was reached", and skipped scenarios are excluded from the `pass_rate` denominator. Print `status` rather than a `passed`/`failed` boolean when triaging.
- If you need every turn evaluated regardless of earlier failures, split them into separate single-turn scenarios instead.
- `AnswerRelevance` is multi-turn aware: it scores only the current turn but sees prior turns as history. Pass `include_history=False` to score a turn in complete isolation.

---

## Example 6: Citation Accuracy (regex + ID existence + LLM judge)

**Setup**: User's agent is instructed to cite sources by `doc_id`. Add a three-layer citation eval — `RegexMatching` for marker presence, `FnCheck` for ID existence in the KB, `LLMJudge` for claim/citation alignment. The layers are ordered cheap → expensive; layer 3 catches the subtle case where the agent cites a real doc that doesn't actually support its claim.

Three setup requirements the SUT must satisfy for the eval to work:

1. **Stable doc IDs**: each KB chunk has a known `doc_id` the agent can emit verbatim.
2. **System prompt**: instructs the model to cite every factual claim with `[doc_id]` in square brackets.
3. **Dict return**: the agent returns `{"answer": str, "context": list[str]}` so the judge can see exactly what sources the agent retrieved.

```python
import asyncio
import re
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite,
    RegexMatching, FnCheck, LLMJudge,
    set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

# 1. KB with stable doc_ids -- the same IDs the agent must cite by.
KB_DOCS = {
    "hr-parental-leave-v3": "Primary caregivers get 16 weeks of paid parental leave; secondary caregivers 8 weeks; available after 6 months tenure.",
    "hr-remote-work-v2":    "Remote work is permitted for all engineering roles, subject to manager approval and a maximum of 4 consecutive weeks abroad per year.",
    "hr-perf-reviews-v1":   "Annual performance reviews occur in January. Reviews include self-assessment, peer feedback, and manager review.",
    "hr-holidays-v2":       "The company observes 12 paid holidays per year plus 5 floating holidays for personal/religious observances.",
}
KB_IDS = set(KB_DOCS)

# 2. Agent stub. The USER's SUT must:
#    - retrieve chunks tagged with their doc_id
#    - include a system prompt that instructs the model to cite via [doc_id]
#    - return a dict so the checks can read both the answer AND the context
async def your_rag_agent(inputs: str) -> dict:
    """REPLACE: call your retriever + LLM here. System prompt MUST instruct
    the model to cite each factual claim with [doc_id]. Example system prompt:

        "Answer questions using ONLY the provided sources. Cite every factual
         claim with the source doc_id in square brackets, e.g. [hr-remote-work-v2]."
    """
    raise NotImplementedError("Replace with your agent")
    # Required return shape (the eval depends on this structure):
    # return {
    #     "answer": "Primary caregivers get 16 weeks of paid leave [hr-parental-leave-v3].",
    #     "context": ["hr-parental-leave-v3: Primary caregivers get 16 weeks..."],
    # }

# 3. Layer 2 helper: extract cited IDs from the answer and verify each one is in the KB.
CITATION_RE = re.compile(r"\[([a-z0-9-]+)\]")

def citations_exist_in_kb(trace) -> bool:
    outputs = trace.last.outputs
    if not isinstance(outputs, dict):
        return False
    cited = set(CITATION_RE.findall(str(outputs.get("answer", ""))))
    return bool(cited) and cited.issubset(KB_IDS)

# 4. Layer 3 judge: Jinja2 template iterating the context the agent retrieved.
JUDGE_PROMPT = """
Examine the agent's answer below. For each citation marker `[doc-id]`, the claim it follows must be supported by the cited source.

Question: {{ trace.last.inputs }}
Agent answer: {{ trace.last.outputs.answer }}

Available sources (id: text):
{% for src in trace.last.outputs.context %}
- {{ src }}
{% endfor %}

Return passed=true if every citation in the answer supports its accompanying claim. Return passed=false if any citation is unsupported (cites the wrong doc, or the cited doc doesn't say what's claimed). Include a one-sentence reason.
""".strip()

QUESTIONS = [
    "How many weeks of parental leave do primary caregivers get?",
    "Can I work remotely from another country?",
    "When are performance reviews held?",
]

scenarios = []
for i, q in enumerate(QUESTIONS):
    scenarios.append(
        Scenario(f"citation_test_{i}")
        .interact(inputs=q)
        # Layer 1: regex sanity check that at least one [doc-id] marker exists
        .check(RegexMatching(
            name="has_citation_marker",
            pattern=r"\[[a-z0-9-]+\]",
            target_key="trace.last.outputs.answer",
        ))
        # Layer 2: cheap deterministic check that every cited ID is real
        .check(FnCheck(
            name="cited_ids_exist_in_kb",
            fn=citations_exist_in_kb,
        ))
        # Layer 3: LLM judge for claim/citation alignment (the strict check)
        .check(LLMJudge(
            name="citations_support_claims",
            prompt=JUDGE_PROMPT,
        ))
        .with_tags(["Dimension:Citations"])
    )

suite = Suite(name="rag_citation_accuracy")
for s in scenarios:
    suite.append(s)

async def main():
    result = await suite.run(target=your_rag_agent, parallel=True)
    result.print_report()
    Path("rag_results.json").write_text(result.model_dump_json(indent=2))
    return result

if __name__ == "__main__":
    asyncio.run(main())
```

**Notes for adapting**:

- `RegexMatching` selects the text with `target_key`. It runs through the PyPI `regex` module with a 2-second `match_timeout_seconds` budget; a catastrophic pattern returns ERROR rather than hanging.
- If the agent cites with a different format (e.g., `(Smith 2020)`, `Source: doc-id`), update both `CITATION_RE` and the `RegexMatching` pattern, and update the system-prompt instruction accordingly.
- If your SUT can't return `{"answer", "context"}`, pre-retrieve context per question and pass it inline to the judge prompt as a static block (drop the `{% for %}` loop).

---

## Example 7: Automatic Quality Scan Alongside a Hand-Written Suite

**Setup**: User has a knowledge base and wants broad coverage fast, plus their own gold-data checks.

`quality_scan` generates hallucination, sycophancy, split-question, multi-topic and out-of-scope scenarios from the documents, runs them, and returns an ordinary `SuiteResult`. Your hand-written suite still carries the things the scan cannot know — gold answers, doc-ID labels, citation format, product-specific rules.

Requires `pip install "giskard[openai,scan]"`.

```python
import asyncio
from pathlib import Path

from giskard.agents import Generator
from giskard.checks import Conformity, Groundedness, Scenario, Suite, set_default_generator
from giskard.scan import KnowledgeBase, quality_scan

set_default_generator(Generator(model="openai/gpt-5.6-terra"))

AGENT_DESCRIPTION = (
    "An internal HR assistant that answers employee questions about benefits, "
    "leave policies and onboarding, grounded in the company handbook."
)

# REPLACE: your KB chunks. from_texts also accepts a plain list[str] passed straight
# to quality_scan; build a KnowledgeBase explicitly when you also want to query it.
KB_CHUNKS = [
    "All employees accrue 20 days of paid vacation per year, prorated by start date.",
    "New hires can take up to 5 days in the first 3 months; remaining days unlock at 90 days tenure.",
    "Vacation must be requested at least 2 weeks in advance via the HR portal.",
    "Primary caregivers get 16 weeks of paid parental leave after 6 months tenure.",
]
knowledge_base = KnowledgeBase.from_texts(KB_CHUNKS)


# REPLACE: your RAG agent
async def your_rag_agent(inputs: str) -> str:
    raise NotImplementedError("Replace with your agent")


# The rules and gold data no generated scenario will guess.
custom_suite = Suite(name="handbook_specific_rules")
custom_suite.append(
    Scenario("cites_handbook_section")
    .interact(inputs="How much notice do I need to give before taking vacation?")
    .check(Groundedness(name="grounded", context=KB_CHUNKS))
    .check(
        Conformity(
            name="cites_a_section",
            rule="The assistant must name the handbook section or policy it is quoting.",
        )
    )
    .with_tags(["Dimension:Citations"])
)


async def main():
    # Breadth: generated knowledge-base quality coverage.
    scan_result = await quality_scan(
        target=your_rag_agent,
        description=AGENT_DESCRIPTION,
        languages=["en"],
        knowledge_base=knowledge_base,
        max_scenarios=30,
        seed=42,
    )

    # Depth: the team's own gold data and product rules.
    custom_result = await custom_suite.run(target=your_rag_agent, parallel=True)
    custom_result.print_report(group_by="Dimension")

    for label, result in (("quality_scan", scan_result), ("custom", custom_result)):
        rate = "n/a" if result.pass_rate is None else f"{result.pass_rate:.1%}"
        print(f"{label}: {rate} over {len(result.results)} scenarios")
        Path(f"{label}_result.json").write_text(result.model_dump_json(indent=2))

    return scan_result, custom_result


if __name__ == "__main__":
    asyncio.run(main())
```

Notes:
- `quality_scan` prints its own report grouped by `component` and attaches a Markdown `recommendation` to the result.
- Omitting `knowledge_base` (or passing an empty one) emits a `RuntimeWarning` and skips nearly every scenario the quality scan would otherwise generate, so always supply documents.
- Pass `target_mode="singleturn"` if the agent cannot hold a conversation; multi-turn-only generators are then skipped and turn budgets capped to 1.
- Scenario generation itself costs LLM calls, so keep `max_scenarios` modest while iterating and fix `seed` for reproducibility.
- To merge instead of reporting side by side, build the generated suite with `giskard.scan.generate_suite(...)` and `append` your hand-written scenarios to it.

---

## Notebook output (instead of script)

If the user is in a Jupyter notebook, package the same code into cells. Recommended cell layout:

**Cell 1 (Setup)**:
```python
from giskard.agents import Generator
from giskard.checks import (
    Scenario, Suite, Groundedness, AnswerRelevance, Conformity,
    set_default_generator,
)

set_default_generator(Generator(model="openai/gpt-5.6-terra"))
```

**Cell 2 (SUT, often already exists in the notebook)**:
```python
# REPLACE: Wire to your existing agent. If the agent is already defined above, you can skip this cell.
# The parameter MUST be named `inputs`; a parameter named `question` raises TypeError.
def your_rag_agent(inputs: str) -> dict:
    return existing_chain.invoke(inputs)
```

**Cell 3 (Test data)**: defining `TEST_CASES`

**Cell 4 (Scenarios + Suite)**: building the suite

**Cell 5 (Run, notebook idiom; no `asyncio.run()`)**:
```python
result = await suite.run(target=your_rag_agent, parallel=True)
result.print_report(group_by="Dimension")
result  # rich pretty-print
```

In notebooks, the cell's last expression is auto-displayed, so just put `result` at the end. Don't write to JSON unless the user asks; that's a script idiom.
